
(function(){"use strict";
  const nav = document.getElementById('siteNav');
  const toggle = document.getElementById('menuToggle');
  if (toggle) toggle.addEventListener('click', ()=>{
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  const path = window.location.pathname.replace(/\/index\.html$/, '/');
  document.querySelectorAll('[data-nav]').forEach(a=>{
    const map={"accueil":"/","produits":"/produits.html","vendeurs":"/vendeurs-legaux.html","apropos":"/a-propos.html","contact":"/contact.html"};
    if (map[a.dataset.nav]=== (path||'/')) a.setAttribute('aria-current','page');
  });
  const f=document.getElementById('contactForm');
  if(f) f.addEventListener('submit',e=>{e.preventDefault();
    const d=new FormData(f);
    const body=`Nom: ${d.get('name')||''}%0AEmail: ${d.get('email')||''}%0ATéléphone: ${d.get('phone')||''}%0A%0A${d.get('message')||''}`;
    location.href=`mailto:contact@promoloco.co?subject=${encodeURIComponent(d.get('subject')||'Demande')}&body=${body}`;
  });
})();